<!DOCTYPE html>
<html>
<head>
	<title>Contact</title>
</head>
<body>
	<h2>CONTACT FOR FULL VERSION</h2>
	<h2>Mail: advancoplanet@gmail.com</h2>
	<h2>Phone: +2348141656572</h2>
	<h2 style="color: red">Full version is not free</h2>
</body>
</html>