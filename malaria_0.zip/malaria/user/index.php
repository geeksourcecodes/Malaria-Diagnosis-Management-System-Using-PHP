<?php
session_start();
if (!$_SESSION['username']){
	echo "<div class='alert alert-success'>No user found</div>";
	
}

?>
<!DOCTYPE html>
<html>
	<head>
			<title>Expert System on Malaria</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel='stylesheet' href='../bootstrap/css/bootstrap.min.css'>
		<link rel="stylesheet" type="text/css" href="../style.css">
		<script src="../jquery.min.js"></script>
		<script src="../bootstrap/js/bootstrap.min.js"></script>
		
	
	</head>
	<body class='bod'>
		<div class="container-fluid">
		<a href='index.php'> <img src='../img/logo.png' height='100' width='300'></a>
		<nav class="navbar navbar-default" id='col'>
  
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header" >
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" id='col2' href="#"></a>
    </div>

</style>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php" id='col2'>Home <span class="sr-only">(current)</span></a></li>
        <li class=""><a href="diagnosis.php" id='col2'>Diagnose <span class="sr-only">(current)</span></a></li>
        <li class=""><a href="view_offence.php" id='col2'>Available Doctors <span class="sr-only">(current)</span></a></li>
        <li class=""><a href="bail.php" id='col2'>About Us <span class="sr-only">(current)</span></a></li>    
      </ul>
      <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Search">
        </div>
      </form>
      <ul class="nav navbar-nav navbar-right">
        
        <li class="dropdown">
          <a href="#" id='nav' class="dropdown-toggle glyphicon glyphicon-user" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <?php echo 'Welcome '.$_SESSION['username']?><span class="caret"></span></a>
          <style type="text/css">
#nav{
	color:white;
}
          </style>
          <ul class="dropdown-menu">
            <li><a href='' data-toggle="modal" data-target="#myModal">
  Manage User
</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="logout.php">Sign Out</a></li>
            
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
 
</nav>

<div class="jumbotron">
  <h1>Welcome to Health Clinic!</h1>
  <p>Help yourself with accurate diagnosis</p>
  <p><a class="btn btn-primary btn-lg" href="#" id='learn' role="button">Learn more</a></p>
  <a class='visit'>Visit School Clinic</a>
  <script type="text/javascript">
  	$(function(){
  		$('.visit').hide();
  		$('#learn').click(function(){
  			$('.visit').toggle('1000');
  		});
  	});
  </script>
</div>

<div class='row'>
	<div class='col-xs-6'>
	<p class='malbody'>Malaria kills about one million, two hundred thousand (1.2 million) people every year. Medical doctors are in limited supply, 
	and provide somewhat expensive services. There is, therefore, the need to build computer-based systems that can assist doctors 
	in diagnosing and recommending treatment for malaria to fill the supply gap and reduce the attendant costs, upon which this 
	research is focused. The expert system would diagnose and recommend treatment of malaria from symptoms and blood test result
	 provided by user patient. The expert system was created based on medical expert information collected through structured interviews, 
	 extensive literature review, and adopting the waterfall software development method. The system is towards reducing deaths associated 
	 with malaria and towards improved health care services, and is a guide to designing similar systems.</p>
	</div>
	<div class='col-xs-3'>
		<img src='../img/mal2.png' width='350' height='200'>
	</div>
	<div class='col-xs-1'>
		
	</div>
	<div class='col-xs-3'>
		<form action='#' method='post'>
				
					
				<div><strong><a href='diagnosis.php'>Diagnose</a></div>
				<div><strong><a href='logout.php'>Available Doctors</a></div>
				
<a href='' data-toggle="modal" data-target="#myModal">
  Manage User
</a>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Manage User</h4>
      </div>
      <div class="modal-body">
       <div class='form-group'>
      <?php
 		include '../conn.php';
 		$a=$_SESSION['id'];
 		$query="SELECT * FROM user INNER JOIN user_d ON user.user_id = user_d.user_id WHERE user.user_id='$a'" ;
			$result=$conn->query($query);
			$row=$result->fetch_assoc();

			
		if (isset($_POST['update'])){
			$geno=$_POST['geno'];
			$blood=$_POST['blood'];
			$phone=$_POST['phone'];
		$query1="UPDATE user_d SET genotype='$geno', blood='$blood', phone='$phone' WHERE user_d.user_id='$a'";
		$result1=$conn->query($query1);
		if(!$result1){
			echo '<div class="alert alert-danger">Something Went Wrong</div>';
		}
		else{
			echo '
<div class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Modal title</h4>
      </div>
      <div class="modal-body">
        <p>One fine body&hellip;</p>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->';

			
		}
		}	
 		?>
       		<form action='' method='post'>
 		
				<label> Username</label>
				<input class='form-control col-xs-6'name='username' value='<?php echo $row["username"]?>' disabled>
				</div>
				<div class='form-group'>
				<label> Genotype</label>
				<select class='form-control' name='geno'>
					<option><?php echo $row["genotype"]?></option>
					<option>AA</option>
					<option>AB</option>
					<option>AC</option>
					<option>AS</option>
					<option>SS</option>
				</select>
				</div>
				<div class='form-group'>
				<label> Blood Group</label>
				<select class='form-control' name='blood'>
					<option><?php echo $row["blood"]?></option>
					<option>O+</option>
					<option>O-</option>
					<option>A+</option>
					<option>A-</option>
					<option>B+</option>
				</select>
				</div>
				<label>Phone Number</label></br>
				
				<input class='form-control'name='phone' value='<?php echo $row["phone"]?>'>	
			</br>
			
      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		        <button class="btn btn-danger" name='update'>Save Changes</button>
		      </div>
		    </div>
		  </div>
		</div>
</form>
				<div><strong><a href='logout.php'>Sign Out</a></div>
				

	</div>
 </div><!-- /.container-fluid -->

	</body>
	<?php
	include '../footer.php';
	?>
</html>

<!-- livezilla.net PLACE SOMEWHERE IN BODY -->
<div id="lvztr_73c" style="display:none"></div><script id="lz_r_scr_00d3e8d7387ab5979eff977ca155b3bf" type="text/javascript" defer>lz_ovlel = [{type:"wm",icon:"commenting"},{type:"chat",icon:"comments",counter:true},{type:"ticket",icon:"envelope"},{type:"knowledgebase",icon:"lightbulb-o",counter:true}];lz_ovlel_rat = 1.2;lz_ovlec = null;lz_code_id="00d3e8d7387ab5979eff977ca155b3bf";var script = document.createElement("script");script.async=true;script.type="text/javascript";var src = "http://localhost/expmalaria/livezilla/server.php?rqst=track&output=jcrpt&fbpos=10&fbw=39&fbh=137&fbmr=40&fbmb=30&ovlv=djI_&ovlc=MQ__&esc=IzEzODA0Qw__&epc=IzEzODA0Qw__&ovlts=MA__&ovlapo=MQ__&nse="+Math.random();script.src=src;document.getElementById('lvztr_73c').appendChild(script);</script><div style="display:none;"><a href="javascript:void(window.open('http://localhost/expmalaria/livezilla/chat.php','','width=400,height=600,left=0,top=0,resizable=yes,menubar=no,location=no,status=yes,scrollbars=yes'))" class="lz_fl"><img id="chat_button_image" src="http://localhost/expmalaria/livezilla/image.php?id=4&type=overlay" width="39" height="137" style="border:0px;" alt="LiveZilla Live Chat Software"></a></div>
<!-- livezilla.net PLACE SOMEWHERE IN BODY -->