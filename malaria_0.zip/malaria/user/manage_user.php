<html>
	<head>
			<title>Expert System on Malaria</title>

		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel='stylesheet' href='../bootstrap/css/bootstrap.min.css'>
		<script src="../jquery.min.js"></script>
		<script src="../bootstrap/js/bootstrap.min.js"></script>
		<link rel='stylesheet' href='style.css'>
</head>
<body>
	<div class='row'>
		<div class='col-md-4'>

		</div>		
		<div class='col-md-4'>
			
			<form class='box' action='' method='post'>
				<h3><center> Sign Up</center></h3>
				<?php
				 include '../conn.php'; 
				 include '../function.php';
				 signup();

?>
				
	
				<div class='form-group'>
				<label> Username</label>
				<input class='form-control col-xs-6'name='username' disabled>	
				</div>
				<div class='form-group'>
				<label> Password</label>
				<input class='form-control col-xs-6'type='password' name='pass' >	
				</div>
				<div class='form-group'>
				<label> Re-Enter Password</label>
				<input type='password'class='form-control col-xs-6'name='c_pass' >	
				</div>
				<div class='form-group'>
				<label> First Name</label>
				<input class='form-control col-xs-6'name='fname' >	
				</div>
				<div class='form-group'>
				<label> Last Name</label>
				<input class='form-control col-xs-6'name='lname' >	
				</div>
				
				<div class='form-group'>
				<label> Sex</label>
				<select class='form-control' name='sex'>
					<option>---Select Option---</option>
					<option>Male</option>
					<option>Female</option>
				</select>
				</div>
				<div class='form-group'>
				<label> Genotype</label>
				<select class='form-control' name='geno'>
					<option>---Select Option---</option>
					<option>AA</option>
					<option>AB</option>
					<option>AC</option>
					<option>AS</option>
					<option>SS</option>
				</select>
				</div>
				
				<label>Phone Number</label></br>
				<div class='form-control'>
				<select class='' name='phone1'>
					<option>234</option>
					<option>091</option>
					<option>222</option>
				</select>
				<input class=''name='phone2' >	
				</div></br>
				<button class='col-md-3 btn btn-success pull-right' name='submit'> Submit</button>
				<a class='rtn' href='index.php'>Return to Homapage</a>
			</form>		
	
		</div>

	</div>
	</body>
	
</html>

