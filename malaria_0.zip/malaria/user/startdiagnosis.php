<?php
session_start();
if (!$_SESSION['username']){
  header("location:../index.php");
  
}
?>
<!DOCTYPE html>
<html>
  <head>
      <title>Expert System on Malaria</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel='stylesheet' href='../bootstrap/css/bootstrap.min.css'>
    <link rel='stylesheet' href='../style.css'>
    <link rel="stylesheet" href="../jqueryui/jquery-ui.css">
    <script src="../jquery.min.js"></script>
    <script src="../jqueryui/jquery-ui.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <link rel='stylesheet' href='../alertify/css/alertify.min.css'>
<script src="../alertify/alertify.min.js"></script>
    
  
  </head>
 
  <body>
    <div class="container-fluid">
    <a href='index.php'> <img src='../img/logo.png' height='50' width='250'></a>
    <nav class="navbar navbar-default" id='col'>
  
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header" >
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" id='col2' href="#"></a>
    </div>
<style>
#col{
    background-color: #1566b2;
    color: white;
}
#col2{
    color: white;
}
</style>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class=""><a href="index.php" id='col2'>Home <span class="sr-only">(current)</span></a></li>
        <li class="active"><a href="diagnosis.php" id='col2'>Diagnose <span class="sr-only">(current)</span></a></li>
        <li class=""><a href="view_offence.php" id='col2'>Available Doctors <span class="sr-only">(current)</span></a></li>
        <li class=""><a href="bail.php" id='col2'>About Us <span class="sr-only">(current)</span></a></li>    
      </ul>
      <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Search">
        </div>
      </form>
      <ul class="nav navbar-nav navbar-right">
        
        <li class="dropdown">
          <a href="#" id='nav' class="dropdown-toggle glyphicon glyphicon-user" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <?php echo 'Welcome '.$_SESSION['username']?><span class="caret"></span></a>
          <style type="text/css">
#nav{
  color:white;
}
          </style>
          <ul class="dropdown-menu">
            <li><a href="edit_user.php">Manage Account</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="logout.php">Sign Out</a></li>
            
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
 
</nav>
<ol class="breadcrumb">
  <li><a href="index.php">Home</a></li>
  <li class='active'><a href="diagnosis.php">Diagnosis</a></li>
  <li class='pull-right'>
    <?php
    include '../conn.php';
    $query="SELECT diag_id FROM diagnosis ORDER BY diag_id DESC";
    $result=$conn->query($query);
    $row=$result->fetch_array() ;
    $diag_id=$row['diag_id'];
    $_SESSION['diag_id']=$diag_id;
    ?>
  Diagnosis ID <span class="badge"><?php echo '00'.$diag_id ?></span></li>
 
</ol>
 </br>
    <div class='row'>
       <div class='col-md-2'>
        <img src='../img/user.png'/>
        <?php
    
    $a=$_SESSION['id'];
    
      ?>
      <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-default">
    <div style="background-color: #13804C; color:white;" class="panel-heading" role="tab" id="headingOne">
      <h4 class="panel-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          Patient ID
        </a>
      </h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
      <div class="panel-body">
        <?php echo '<p class="badge"> PAT00'.$_SESSION['id'].'<p>'?>
      </div>
    </div>
  </div>
        </div> 
        
        <div class='col-md-4 diag'>
         
          <form method='post' class='fd' action='' enctype="multipart/form-data">
        <?php
        echo"<h2 style='color: white'>Symptoms</h2><hr/>";
          $query="SELECT * FROM questions WHERE q_id=".$_SESSION['current_id'];
          $result=$conn->query($query);
        $row=$result->fetch_assoc();
        //show question
          echo "<p class='question'>".$row['question']."</p>"; 
          $qrow=$row['q_id'];
        //save option yes to d database
        if(isset($_POST['yes']) || isset($_POST['no'])) {
          $lol=$_POST['lol'];
          $cnt=$_SESSION['current_id']-1;
         $query="UPDATE diagnosis SET answer".$cnt."='$lol' WHERE diag_id='$diag_id'";
         $result=$conn->query($query);
        }
        //select last question
        $query2="SELECT q_id FROM questions ORDER BY q_id DESC LIMIT 1";
          $result2=$conn->query($query2);
          $row2= $result2->fetch_array();
          $rw=$row2['q_id'];
          $cr=$_SESSION['current_id'];
          if($cr-$rw==1){
            echo "<script type='text/javascript'>
             alertify.alert('Diagnosis Has been Completed');
           </script>";
           echo "<meta http-equiv='refresh' content='2; url=result.php' />";
          }
          //if question == current increment session
          ob_end_flush();
        ?>

          <button class='btn btn-success btn-lg' name='yes' id='y'>Yes</button> || <button class='btn btn-success btn-lg' name='no' id='no'>No</button></br></br>
          <input type="text" name="lol" id='choice' value='' hidden>
           </fieldset>
          
         <script type="text/javascript">
  $(document).ready(function(){
  $(".btn").click(function(){
    $.post("fetch.php", function(data){
        document.write(data);
    });
    var b=this.name;
   $('#choice').val(b);
}); 
 });
  
 </script>
          </form>
          
        </div>  
 <!-- /.container-fluid --> 
-
    </div> 

 </div>

  </body>
  
</html>

<style>
body{
  background-color: #f8ffc9;
}
form{
  margin-left: 15px;
}
.malbody{
  text-align: justify;
  border: solid 2px;
  border-radius: 20px;
  padding: 20px;
}

</style>
<!-- livezilla.net PLACE SOMEWHERE IN BODY -->
<div id="lvztr_73c" style="display:none"></div><script id="lz_r_scr_00d3e8d7387ab5979eff977ca155b3bf" type="text/javascript" defer>lz_ovlel = [{type:"wm",icon:"commenting"},{type:"chat",icon:"comments",counter:true},{type:"ticket",icon:"envelope"},{type:"knowledgebase",icon:"lightbulb-o",counter:true}];lz_ovlel_rat = 1.2;lz_ovlec = null;lz_code_id="00d3e8d7387ab5979eff977ca155b3bf";var script = document.createElement("script");script.async=true;script.type="text/javascript";var src = "http://localhost/expmalaria/livezilla/server.php?rqst=track&output=jcrpt&fbpos=10&fbw=39&fbh=137&fbmr=40&fbmb=30&ovlv=djI_&ovlc=MQ__&esc=IzEzODA0Qw__&epc=IzEzODA0Qw__&ovlts=MA__&ovlapo=MQ__&nse="+Math.random();script.src=src;document.getElementById('lvztr_73c').appendChild(script);</script><div style="display:none;"><a href="javascript:void(window.open('http://localhost/expmalaria/livezilla/chat.php','','width=400,height=600,left=0,top=0,resizable=yes,menubar=no,location=no,status=yes,scrollbars=yes'))" class="lz_fl"><img id="chat_button_image" src="http://localhost/expmalaria/livezilla/image.php?id=4&type=overlay" width="39" height="137" style="border:0px;" alt="LiveZilla Live Chat Software"></a></div>
<!-- livezilla.net PLACE SOMEWHERE IN BODY -->