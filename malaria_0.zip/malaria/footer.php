
<footer>
	<div class='container-fluid col-lg'>
	<p>A Richiehortiz Design &copy; 2017</p>
</div>
</footer>	

