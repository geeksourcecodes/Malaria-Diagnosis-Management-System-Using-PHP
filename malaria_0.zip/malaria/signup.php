<html>
	<head>
			<title>Expert System on Malaria</title>

		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel='stylesheet' href='bootstrap/css/bootstrap.min.css'>
		 <link rel="stylesheet" href="jqueryui/jquery-ui.css">
		<link rel='stylesheet' href='style.css'>
		<script src="jquery.min.js"></script>
	<script src="jqueryui/jquery-ui.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>
		
</head>
<style type="text/css">
	body{
		background-image: url("img/back.png");
		background-repeat: no-repeat;
		background-position: center;
		background-size: contain;
	}
</style>
<body>
	<div class='cover'>
	<div class='row'>
		<div class='col-md-4'>

		</div>		
		<div class='col-md-4'>
			
			<form action='' method='post'>
				<h3><center> Sign Up</center></h3>
				<?php
				 include 'conn.php'; 
				 include 'function.php';
				 signup();
				 

?>
				
	
				<div class='form-group'>
				<label> Username</label>
				<input class='form-control col-xs-6'name='username' >	
				</div>
				<div class='form-group'>
				<label> Password</label>
				<input class='form-control col-xs-6'type='password' name='pass' >	
				</div>
				<div class='form-group'>
				<label> Re-Enter Password</label>
				<input type='password'class='form-control col-xs-6'name='c_pass' >	
				</div>
				<div class='form-group'>
				<label> First Name</label>
				<input class='form-control col-xs-6'name='fname' >	
				</div>
				<div class='form-group'>
				<label> Last Name</label>
				<input class='form-control col-xs-6'name='lname' >	
				</div>
				<div class='form-group'>
				<label> D.O.B (DD-MM-YYYY)</label>
				<input type='text' class='form-control col-xs-6' id='dr' name='dob' >	
				  <script>
  $( function() {
    $( "#dr" ).datepicker({
      changeMonth: true,
      changeYear: true,
    dateFormat: "dd/mm/yy" }).val();
         
  } );
  </script>
				</div>
				<div class='form-group'>
				<label> Sex</label>
				<select class='form-control' name='sex'>
					<option>---Select Option---</option>
					<option>Male</option>
					<option>Female</option>
				</select>
				</div>
				<div class='form-group'>
				<label> Genotype</label>
				<select class='form-control' name='geno'>
					<option>---Select Option---</option>
					<option>AA</option>
					<option>AB</option>
					<option>AC</option>
					<option>AS</option>
					<option>SS</option>
				</select>
				</div>
				<div class='form-group'>
				<label> Blood Group</label>
				<select class='form-control' name='blood'>
					<option>---Select Option---</option>
					<option>O+</option>
					<option>O-</option>
					<option>A+</option>
					<option>A-</option>
					<option>B+</option>
				</select>
				</div>
				
				<label>Phone Number</label></br>
				<div class='form-control'>
				<select class='' name='phone1'>
					<option>234</option>
					<option>091</option>
					<option>222</option>
				</select>
				<input class=''name='phone2' >	
				</div></br>
				<button class='col-md-3 btn btn-success pull-right' name='submit'> Submit</button>
				<a class='rtn' href='index.php'>Return to Homapage</a>
			</form>		
	
		</div>

	</div>
</div>
	</body>
	 
</html>

<!-- livezilla.net PLACE SOMEWHERE IN BODY -->
<div id="lvztr_73c" style="display:none"></div><script id="lz_r_scr_00d3e8d7387ab5979eff977ca155b3bf" type="text/javascript" defer>lz_ovlel = [{type:"wm",icon:"commenting"},{type:"chat",icon:"comments",counter:true},{type:"ticket",icon:"envelope"},{type:"knowledgebase",icon:"lightbulb-o",counter:true}];lz_ovlel_rat = 1.2;lz_ovlec = null;lz_code_id="00d3e8d7387ab5979eff977ca155b3bf";var script = document.createElement("script");script.async=true;script.type="text/javascript";var src = "http://localhost/expmalaria/livezilla/server.php?rqst=track&output=jcrpt&fbpos=10&fbw=39&fbh=137&fbmr=40&fbmb=30&ovlv=djI_&ovlc=MQ__&esc=IzEzODA0Qw__&epc=IzEzODA0Qw__&ovlts=MA__&ovlapo=MQ__&nse="+Math.random();script.src=src;document.getElementById('lvztr_73c').appendChild(script);</script><div style="display:none;"><a href="javascript:void(window.open('http://localhost/expmalaria/livezilla/chat.php','','width=400,height=600,left=0,top=0,resizable=yes,menubar=no,location=no,status=yes,scrollbars=yes'))" class="lz_fl"><img id="chat_button_image" src="http://localhost/expmalaria/livezilla/image.php?id=4&type=overlay" width="39" height="137" style="border:0px;" alt="LiveZilla Live Chat Software"></a></div>
<!-- livezilla.net PLACE SOMEWHERE IN BODY -->