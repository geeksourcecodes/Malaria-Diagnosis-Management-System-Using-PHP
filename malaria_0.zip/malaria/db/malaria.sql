-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 05, 2018 at 07:15 PM
-- Server version: 5.7.9
-- PHP Version: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `malaria`
--

-- --------------------------------------------------------

--
-- Table structure for table `diagnosis`
--

DROP TABLE IF EXISTS `diagnosis`;
CREATE TABLE IF NOT EXISTS `diagnosis` (
  `diag_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `q1_id` int(11) NOT NULL,
  `answer1` varchar(50) NOT NULL,
  `q2_id` int(11) NOT NULL,
  `answer2` varchar(50) NOT NULL DEFAULT 'blank',
  `q3_id` int(50) NOT NULL,
  `answer3` varchar(50) NOT NULL,
  `q4_id` int(50) NOT NULL,
  `answer4` varchar(50) NOT NULL,
  `q5_id` int(50) NOT NULL,
  `answer5` varchar(50) NOT NULL,
  `q6_id` int(50) NOT NULL,
  `answer6` varchar(50) NOT NULL,
  `q7_id` int(50) NOT NULL,
  `answer7` varchar(50) NOT NULL,
  `q8_id` int(11) NOT NULL,
  `answer8` varchar(50) NOT NULL,
  `q9_id` int(11) NOT NULL,
  `answer9` varchar(50) NOT NULL,
  `q10_id` int(11) NOT NULL,
  `answer10` varchar(50) NOT NULL,
  `q11_id` int(11) NOT NULL,
  `answer11` varchar(50) NOT NULL,
  `q12_id` int(11) NOT NULL,
  `answer12` varchar(50) NOT NULL,
  `q13_id` int(11) NOT NULL,
  `answer13` varchar(50) NOT NULL,
  `q14_id` int(11) NOT NULL,
  `answer14` varchar(50) NOT NULL,
  `q15_id` int(11) NOT NULL,
  `answer15` varchar(50) NOT NULL,
  `q16_id` int(11) NOT NULL,
  `answer16` varchar(50) NOT NULL,
  PRIMARY KEY (`diag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `diagnosis`
--

INSERT INTO `diagnosis` (`diag_id`, `user_id`, `q1_id`, `answer1`, `q2_id`, `answer2`, `q3_id`, `answer3`, `q4_id`, `answer4`, `q5_id`, `answer5`, `q6_id`, `answer6`, `q7_id`, `answer7`, `q8_id`, `answer8`, `q9_id`, `answer9`, `q10_id`, `answer10`, `q11_id`, `answer11`, `q12_id`, `answer12`, `q13_id`, `answer13`, `q14_id`, `answer14`, `q15_id`, `answer15`, `q16_id`, `answer16`) VALUES
(1, 1, 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0'),
(2, 1, 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0'),
(3, 1, 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0'),
(4, 1, 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0'),
(5, 1, 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0'),
(6, 1, 0, 'yes', 0, 'no', 0, 'no', 0, '', 0, 'no', 0, '', 0, 'no', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0', 0, '0'),
(7, 1, 0, 'no', 0, 'no', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'no', 0, 'no', 0, 'no'),
(8, 1, 0, 'no', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no'),
(9, 1, 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, ''),
(10, 1, 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no'),
(11, 1, 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no'),
(12, 7, 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, '', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'no', 0, 'no', 0, 'no', 0, 'no'),
(13, 7, 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, ''),
(14, 1, 0, 'yes', 0, 'no', 0, 'yes', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'no', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'yes', 0, 'no', 0, 'no'),
(15, 1, 0, 'yes', 0, 'yes', 0, 'yes', 0, 'no', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, ''),
(16, 1, 0, '', 0, 'yes', 0, 'no', 0, 'no', 0, 'yes', 0, 'yes', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, ''),
(17, 1, 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `q_id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  PRIMARY KEY (`q_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`q_id`, `question`) VALUES
(1, 'Do you have Headache?'),
(2, 'Do you have cough?'),
(3, 'Do you have pain?'),
(4, 'Do you sleep fine?'),
(5, 'Do you have catarh?'),
(6, 'Are you sneezing?'),
(7, 'Have you been sweating profusely?'),
(8, 'Have you been shivering?'),
(9, 'Are you feeling tired?'),
(10, 'Are you having convulsions?'),
(11, 'Are you having abdominal bleeding'),
(12, 'Are you having abdominal pain?'),
(13, 'Are you having diarrhea?'),
(14, 'Are you having anemia?'),
(15, 'Are you having bloody stools?'),
(16, 'Are you having muscle pains?');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

DROP TABLE IF EXISTS `result`;
CREATE TABLE IF NOT EXISTS `result` (
  `sn` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(250) NOT NULL,
  `result` varchar(250) NOT NULL,
  `date` varchar(200) NOT NULL,
  `time` varchar(150) NOT NULL,
  PRIMARY KEY (`sn`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`sn`, `username`, `result`, `date`, `time`) VALUES
(1, 'bimbo', 'Malaria level has been determined to be severely critical, Please visit a doctor as soon as possible. Self Medication can be dangerous to you health', 'Thu,12/07/18', '2:50pm'),
(2, 'bimbo', 'Malaria level has been determined to be severely critical, Please visit a doctor as soon as possible. Self Medication can be dangerous to you health', 'Thu,12/07/18', '3:01pm'),
(3, 'bimbo', 'hello', 'Fri,13/07/18', '12:51pm'),
(4, 'bimbo', 'Malaria level has been determined to be severely critical, Please visit a doctor as soon as possible. Self Medication can be dangerous to you health', 'Wed,18/07/18', '4:58pm'),
(5, 'bimbo', 'Very High Level Malaria Symptoms Detected', 'Wed,18/07/18', '5:05pm'),
(6, 'bimbo', 'Early stage of Malaria Detected', 'Wed,18/07/18', '5:07pm'),
(7, 'GOOD', 'Very High Level Malaria Symptoms Detected', 'Thu,19/07/18', '9:46am');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(40) NOT NULL,
  `password` varchar(30) NOT NULL,
  `c_pass` varchar(30) NOT NULL,
  `role` varchar(20) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`, `c_pass`, `role`) VALUES
(1, 'bimbo', 'bimbo', 'bimbo', 'user'),
(2, 'aluko', 'aluko123', 'aluko123', 'user'),
(3, 'lola', 'fceeb9b9d469401fe558062c4bd259', 'fceeb9b9d469401fe558062c4bd259', 'user'),
(4, 'abusi', '81f700b9cffd20201bc3bfb2ee21d1', '81f700b9cffd20201bc3bfb2ee21d1', 'user'),
(5, 'a', '0cc175b9c0f1b6a831c399e2697726', '0cc175b9c0f1b6a831c399e2697726', 'user'),
(6, 'admin', 'admin', '21232f297a57a5a743894a0e4a801f', 'user'),
(7, 'good', 'good', 'good', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `user_d`
--

DROP TABLE IF EXISTS `user_d`;
CREATE TABLE IF NOT EXISTS `user_d` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(40) NOT NULL,
  `lname` varchar(40) NOT NULL,
  `dob` varchar(30) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `genotype` varchar(10) NOT NULL,
  `blood` varchar(6) NOT NULL,
  `phone` varchar(20) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_d`
--

INSERT INTO `user_d` (`user_id`, `fname`, `lname`, `dob`, `sex`, `genotype`, `blood`, `phone`) VALUES
(1, 'Soneye', 'Oluwasina', '12/5/2017', 'Male', 'AC', 'O+', '2348183385094'),
(2, 'aluko', 'o', '12/5/2017', 'Male', 'AS', 'O-', '23478239321'),
(3, 'lola', 'lola', '12/5/2017', 'Female', 'SS', 'A-', '234818443432'),
(4, 'abusi', 'abusi', '05/12/1989', 'Male', 'AS', 'O+', '2348183385094'),
(5, 'good', 'good', '19/07/2018', 'Male', 'AA', 'O+', '2345864344384');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
