<?php 

function signup(){
	include 'conn.php';
if(isset($_POST['submit'])){
	$b=0;
	$username= $conn->real_escape_string($_POST['username']);
	$pass= $_POST['pass'];
	$c_pass= $_POST['c_pass'];
	$fname	= $_POST['fname'];
	$lname	= $_POST['lname'];
	$dob	= $_POST['dob'];
	$sex	= $_POST['sex'];
	$geno	= $_POST['geno'];
	$blood=$_POST['blood'];
	$phone1	= $_POST['phone1'];
	$phone2	= $_POST['phone2'];
	$pass=$pass;
	$c_pass=$c_pass;
	$phone=$phone1.$phone2;

if (empty($username) || empty($pass)|| empty($c_pass)|| empty($fname)|| empty($lname)
	|| empty($dob)|| empty($sex)|| empty($geno)|| empty($phone2) || empty($blood)){
	echo '<div class="alert alert-danger">Field cannot be empty</div>';
}
else{
		$query="INSERT INTO user VALUES (null, '$username','$pass','$c_pass','user')";
		$query1="INSERT INTO user_d VALUES (null, '$fname','$lname','$dob','$sex', '$geno','$blood', '$phone')";
		$result=$conn->query($query);
		$result1=$conn->query($query1);
		if(!$result){
			echo '<div class="alert alert-danger">Something Went Wrong</div>';
		}
		else{
			echo '<div class="alert alert-success">Profile Created Successfully</div>';
			header('refresh:3;url=index.php');
		}
		}
	}

}

function manage_user(){
	include 'conn.php';
	$a=$_SESSION['id'];
	echo $a;
		$query="SELECT * FROM USER where user_id='$a'";
		$result=$conn->query($query);
		 $row=$result->fetch_assoc();
		
		}
	
?>
